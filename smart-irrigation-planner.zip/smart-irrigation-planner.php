<?php
/*
Plugin Name: Smart Irrigation & Water Usage Planner
Description: Suggests irrigation timing and volume based on field size, crop type, rainfall and soil moisture. Includes client-side CSV and PDF export.
Version: 1.0
Author: ChatGPT
*/

if (!defined('ABSPATH')) exit;

// Shortcode
function sip_shortcode() {
    ob_start(); ?>
    <div class="sip-container">
      <h2>Smart Irrigation & Water Usage Planner</h2>
      <p class="sip-intro">Enter field details and recent weather to get irrigation recommendations and conservation alerts.</p>

      <form id="sip-form" onsubmit="return false;" class="sip-form">
        <div class="sip-row"><label>Field area</label><input id="sip-area" type="number" min="0" step="0.01" placeholder="acres" required></div>
        <div class="sip-row"><label>Crop type</label>
          <select id="sip-crop">
            <option value="corn">Corn</option>
            <option value="soybean">Soybean</option>
            <option value="wheat">Wheat</option>
            <option value="alfalfa">Alfalfa</option>
            <option value="pasture">Pasture</option>
          </select>
        </div>
        <div class="sip-row"><label>Recent rainfall (mm in last 7 days)</label><input id="sip-rain" type="number" min="0" step="0.1" placeholder="mm"></div>
        <div class="sip-row"><label>Soil moisture (%) - optional (sensor)</label><input id="sip-soil" type="number" min="0" max="100" step="0.1" placeholder="vol%"></div>
        <div class="sip-row"><label>Irrigation system efficiency (%)</label><input id="sip-eff" type="number" min="0" max="100" value="75"></div>
        <div class="sip-row"><label>Days since last irrigation</label><input id="sip-days" type="number" min="0" value="7"></div>

        <div class="sip-actions">
          <button id="sip-calc" type="button">Get Recommendation</button>
          <button id="sip-reset" type="reset">Reset</button>
        </div>
      </form>

      <div id="sip-result" class="sip-result" style="display:none;">
        <h3>Recommendation</h3>
        <div id="sip-summary" class="sip-summary"></div>
        <div id="sip-alert" class="sip-alert"></div>
        <div id="sip-details" class="sip-details"></div>

        <div class="sip-export">
          <button id="sip-csv" type="button">Export CSV</button>
          <button id="sip-pdf" type="button">Download PDF</button>
        </div>
      </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('smart_irrigation_planner', 'sip_shortcode');

// enqueue assets
function sip_enqueue_assets() {
    wp_enqueue_style('sip-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), null, true);
    wp_enqueue_script('sip-js', plugin_dir_url(__FILE__) . 'assets/js/sip.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts','sip_enqueue_assets');
?>