
(function(){
  function qs(sel){ return document.querySelector(sel); }
  function formatNumber(n,dec=1){ return Number(Math.round(n* Math.pow(10,dec))/Math.pow(10,dec)).toLocaleString(); }

  const cropKc = { corn:1.15, soybean:1.05, wheat:0.8, alfalfa:1.2, pasture:0.9 };

  function estimateET0(temperatureC=25, humidity=60){
    let et = 4 + (temperatureC - 25) * 0.12 - Math.max(0, (humidity - 50)) * 0.01;
    return Math.max(0.5, et);
  }

  qs('#sip-calc').addEventListener('click', function(){
    const area = parseFloat(qs('#sip-area').value) || 0;
    const crop = qs('#sip-crop').value;
    const rain = parseFloat(qs('#sip-rain').value) || 0;
    const soil = qs('#sip-soil').value ? parseFloat(qs('#sip-soil').value) : null;
    const eff = parseFloat(qs('#sip-eff').value) / 100 || 0.75;
    const days = parseInt(qs('#sip-days').value) || 7;

    if(area <= 0){ alert('Enter a valid field area in acres.'); return; }

    let temp = parseFloat(prompt('Enter recent average temperature (°C) for the last week (e.g., 25):', '25')) || 25;
    let humidity = parseFloat(prompt('Enter recent average relative humidity (%) for the last week (e.g., 60):', '60')) || 60;

    const et0_daily = estimateET0(temp, humidity);
    const et0_period = et0_daily * days;
    const kc = cropKc[crop] || 1.0;
    const etc = et0_period * kc;

    const effectiveRain = rain;
    let soilContribution = 0;
    if(soil !== null){ soilContribution = soil * 0.3; }

    let deficit = Math.max(0, etc - effectiveRain - soilContribution);

    const m3_per_mm_per_acre = 4.04686;
    const volume_m3 = deficit * area * m3_per_mm_per_acre;
    const gallons = volume_m3 * 264.172052;
    const required_gallons = gallons / eff;
    const required_m3 = required_gallons / 264.172052;

    let alert = '';
    if(deficit <= 2) alert = 'Low immediate need — consider delaying irrigation and monitor soil moisture.';
    else if(deficit <= 10) alert = 'Moderate need — schedule targeted irrigation and prioritize areas with lower soil moisture.';
    else alert = 'High need — irrigate soon. Consider deficit-reducing strategies and prioritize water-efficient application.';

    let droughtRisk = 'Low';
    if(humidity < 40 && temp > 28 && deficit > 10) droughtRisk = 'High';
    else if(deficit > 8) droughtRisk = 'Moderate';

    const report = {
      timestamp: new Date().toISOString(),
      area_acres: area,
      crop: crop,
      period_days: days,
      temp_c: temp,
      humidity: humidity,
      et0_daily_mm: Number(et0_daily.toFixed(2)),
      etc_mm: Number(etc.toFixed(2)),
      rain_mm: effectiveRain,
      soil_mm_equiv: Math.round(soilContribution*10)/10,
      deficit_mm: Number(deficit.toFixed(2)),
      required_gallons: Math.round(required_gallons),
      required_m3: Number(required_m3.toFixed(2)),
      irrigation_efficiency: eff,
      alert: alert,
      droughtRisk: droughtRisk
    };

    qs('#sip-result').style.display = 'block';
    qs('#sip-summary').innerHTML = `<strong>Water needed:</strong> ${formatNumber(report.deficit_mm,2)} mm over ${report.period_days} days — ≈ ${formatNumber(report.required_gallons,0)} gallons (≈ ${formatNumber(report.required_m3,2)} m³).`;
    qs('#sip-alert').innerHTML = `<strong>Conservation Alert:</strong> ${report.alert} <br/><strong>Drought Risk:</strong> ${report.droughtRisk}`;
    qs('#sip-details').innerHTML = `<pre style="white-space:pre-wrap">${JSON.stringify(report, null, 2)}</pre>`;
    qs('#sip-result').dataset.report = JSON.stringify(report);
  });

  qs('#sip-reset').addEventListener('click', function(){ qs('#sip-result').style.display = 'none'; delete qs('#sip-result').dataset.report; });

  qs('#sip-csv').addEventListener('click', function(){
    const rep = qs('#sip-result').dataset.report;
    if(!rep){ alert('Please generate a recommendation first.'); return; }
    const obj = JSON.parse(rep);
    const headers = Object.keys(obj);
    const values = headers.map(h => typeof obj[h] === 'string' ? '"' + obj[h].replace(/"/g,'""') + '"' : obj[h]);
    const csv = headers.join(',') + '\n' + values.join(',');
    const blob = new Blob([csv], {type: 'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'irrigation_plan_' + obj.timestamp.split('T')[0] + '.csv'; document.body.appendChild(a); a.click(); document.body.removeChild(a);
  });

  qs('#sip-pdf').addEventListener('click', function(){
    const rep = qs('#sip-result').dataset.report;
    if(!rep){ alert('Please generate a recommendation first.'); return; }
    const obj = JSON.parse(rep);
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({unit:'pt', format:'letter'});
    let y = 40;
    doc.setFontSize(16); doc.text('Smart Irrigation Plan Report', 40, y); y += 24;
    doc.setFontSize(11);
    doc.text('Generated: ' + new Date(obj.timestamp).toLocaleString(), 40, y); y += 16;
    doc.text('Field area (acres): ' + obj.area_acres, 40, y); y += 14;
    doc.text('Crop: ' + obj.crop, 40, y); y += 14;
    doc.text('Period (days): ' + obj.period_days, 40, y); y += 14;
    doc.text('Avg Temp (°C): ' + obj.temp_c + '  Humidity: ' + obj.humidity + '%', 40, y); y += 14;
    doc.text('ET0 (mm/day): ' + obj.et0_daily_mm + '  ETc (mm): ' + obj.etc_mm, 40, y); y += 14;
    doc.text('Rain (mm): ' + obj.rain_mm + '  Soil mm equiv: ' + obj.soil_mm_equiv, 40, y); y += 14;
    doc.text('Deficit: ' + obj.deficit_mm + ' mm', 40, y); y += 14;
    doc.text('Required water: ' + obj.required_gallons + ' gallons (≈ ' + obj.required_m3 + ' m³) adjusted for efficiency', 40, y); y += 18;
    doc.text('Conservation Alert: ' + obj.alert, 40, y); y += 16;
    doc.text('Drought Risk: ' + obj.droughtRisk, 40, y); y += 20;
    doc.save('irrigation_plan_' + obj.timestamp.split('T')[0] + '.pdf');
  });
})();